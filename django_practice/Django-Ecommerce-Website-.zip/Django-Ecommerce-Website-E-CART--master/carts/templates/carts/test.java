Class threadTest implements runnable{
	Public void run();
	{
		Sop(“threadTest”);
}
}

Class test extends Thread{
	

}
