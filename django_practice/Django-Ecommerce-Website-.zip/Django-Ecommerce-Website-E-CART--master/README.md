# Django-Ecommerce-Website-E-CART-

HOW TO RUN:

This program works on Python3
Follow the steps given bellow:
1. Create a Virtual Environment  --->     virtualenv ecart
2. Create a directory called "src" inside this environment
3. go inside "src" and put this repository inside it.
4. activate virtual environment "ecart" using the command --->    . .\Scritps\activate
5. install all requirements from given requirements.txt file. you can use command  --->   pip install -r requirements.txt
6. Run the project using command  --->   python manage.py runserver
7. copy the localhost address and paste it on your browser and open it.
